sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("ns.UI5.controller.rootView", {

		onInit: function () {

		}
	});

});